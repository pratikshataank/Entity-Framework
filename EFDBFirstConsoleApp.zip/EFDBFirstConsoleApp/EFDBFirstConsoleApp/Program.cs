﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFDBFirstConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeDBEntities context = new EmployeeDBEntities();
            var employee1 = context.Emloyees;
            /* employee1.Add(new Emloyee {EmpID=1,Name="pratiksha",Salary=30000,DepID=3 });
             context.SaveChanges();*/

            var employee2 = context.Emloyees;
            employee2.Add(new Emloyee {EmpID=2,Name="xyz",Salary=40000,DepID=2});
            context.SaveChanges();

            Console.ReadKey();


        }
    }
}
