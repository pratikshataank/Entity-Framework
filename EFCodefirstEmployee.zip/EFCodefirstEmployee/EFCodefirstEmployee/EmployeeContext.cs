﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;



namespace EFCodefirstEmployee
{
    class EmployeeContext : DbContext
    {
        public EmployeeContext() : base("EmployeeDeptContext") { }
        public DbSet<Employee> Emp { get; set; }
        public DbSet<Department> Dept { get; set; }

    }
}
