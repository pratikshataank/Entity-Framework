﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodefirstEmployee
{
    class Program
    {
        static void Main(string[] args)
        {
            insertdept();
            ShowDept();
            insertemp();
            ShowEmp();
        }

        //department table
        private static void insertdept()
        {
            EmployeeContext dc = new EmployeeContext();

            Console.WriteLine("enter department name:");
            string DeptName = Console.ReadLine();

            Console.WriteLine("enter location");
            string loctn = Console.ReadLine();

            Department dpr = new Department
            {
                Dname = DeptName,
                Location = loctn
             
            };
            dc.Dept.Add(dpr);
            dc.SaveChanges();
        }

        public static void ShowDept()
        {
            EmployeeContext ddx = new EmployeeContext();
            var departments = ddx.Dept;
            foreach (var drd in departments)
            {
                Console.WriteLine("{0}\t{1}\t{2}", drd.Did,drd.Dname,drd.Location);
            }
        }

        //employee table
        private static void insertemp()
        {
            EmployeeContext emp = new EmployeeContext();

            Console.WriteLine("enter employee id:");
            int empid = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter employee name:");
            string empname = Console.ReadLine();

            Console.WriteLine("enter designtion:");
            string designaion = Console.ReadLine();

            Console.WriteLine("enter id:");
            int id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter salary");
            double sal = Convert.ToDouble(Console.ReadLine());

         Employee epr = new Employee
         {
           
             Eid=empid,
             Ename=empname,
             Designation=designaion,
             Did=id,
             Salary=sal


         };
            emp.Emp.Add(epr);
            emp.SaveChanges();
        }

        public static void ShowEmp()
        {
          EmployeeContext ecx = new EmployeeContext();
            var Employess = ecx.Emp;
            foreach (var erd in Employess)
            {
                Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}", erd.Eid,erd.Ename,erd.Designation,erd.Did,erd.Salary);
            }
        }
    }
}
