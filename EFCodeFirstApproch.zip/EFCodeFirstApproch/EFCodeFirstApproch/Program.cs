﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Migrations;


namespace EFCodeFirstApproch
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductDBContext con = new ProductDBContext();
            var product = con.Products;
            product.Add(new Product
            {
                pname = "cofee",
            price = 100.00
            });
            con.SaveChanges();
        }
    }

    public class ProductDBContext:DbContext
    {
        public ProductDBContext():base("ProductDBContext")
        {
        }

        public DbSet<Product> Products { get; set; }
    }



    public class Product
    {
        public int ID { get; set; }
        public string pname { get; set; }
        public double price { get; set; }
    }


}
