﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity; //neeed for DbContext

namespace EFCodeFirstDemoConsoleApp
{
    class ProductContext : DbContext
    {
        public ProductContext() : base("ProductContext") { } //constructor of ProductContext class,this constructor inherit with base class constructor
        public DbSet<Product> products { get; set; } //dbset represent collection of table entities
    }
}
