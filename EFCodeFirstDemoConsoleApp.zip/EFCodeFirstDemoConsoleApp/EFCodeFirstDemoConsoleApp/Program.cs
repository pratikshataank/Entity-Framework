﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFCodeFirstDemoConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {


            ShowData();
            //insert();
            
            Console.ReadKey();
        }

        private static void insert()
        {
            ProductContext pcx = new ProductContext();
          //  Console.WriteLine("enter product id:");
          //  int pid = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter product name:");
            string pname = Console.ReadLine();

            Console.WriteLine("enter price:");
            double price = Convert.ToDouble(Console.ReadLine());

            Product prd = new Product
            {
               // Pid = pid,
                Ptitle = pname,
                Price = price
            };

            pcx.products.Add(prd);
            pcx.SaveChanges();
        }

        public static void ShowData()
        {
            ProductContext pdx = new ProductContext();
            var products = pdx.products;
            foreach (var prd in products)
            {
                Console.WriteLine("{0}\t{1}\t{2}", prd.Pid, prd.Ptitle, prd.Price);
            }
        }
    }
}
