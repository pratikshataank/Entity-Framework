﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations; //needed for [key] attribute

namespace EFCodeFirstDemoConsoleApp
{
    class Product
    {
        //key attribute generate primary key
        [Key]
        public int Pid { get; set; }

        [Required] //we use it for Ptitle ,it cant be null
        public string Ptitle { get; set; }

        public double Price { get; set; }


    }
}
